/*
	widthlist: output character list which has real width
	usage: echo UCS4 | ./widthlist
		or echo UCS4 | ./widthlist -cjk
*/
#include <stdio.h>
#include "wcwidth.h"

enum {
	UCS4_MAX = 0x10FFFF,
	BUFSIZE = 1024,
};

int main(int argc, char **argv)
{
	unsigned int ucs;
	char buf[BUFSIZE], **endp;
	int (*func)(wchar_t ucs);

	if (argc < 2)
		func = mk_wcwidth;
	else
		func = mk_wcwidth_cjk;

	while (fgets(buf, BUFSIZE, stdin) != NULL) {
		ucs = strtol(buf, &endp, 16);
		printf("%d\n", func(ucs));
	}
}
