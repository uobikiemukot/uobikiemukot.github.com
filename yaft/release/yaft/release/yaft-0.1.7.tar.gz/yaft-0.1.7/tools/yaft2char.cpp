/*
	yaft2char: convert yaft font to readable ascii format
	usage: ./yaft2char FILE
*/
#include "util.cpp"

using namespace std;

void dump_char(glyph_t &glyph)
{
	int i, j, wide;

	cout << glyph.width << " " << glyph.height << endl;
	wide = ceil((double) glyph.width / BITS_PER_BYTE) * BITS_PER_BYTE;

	//cout << "wide:" << wide << endl;

	for (i = 0; i < glyph.bitmap.size(); i++) {
		//cout << "bitmap:" << hex << glyph.bitmap[i] << endl;
		for (j = 1; j <= wide; j++) {
			if (glyph.bitmap[i] & 0x01 << (wide - j))
				cout << "@";
			else
				cout << ".";
		}
		cout << endl;
	}

	cout.unsetf(ios::hex | ios::uppercase);
}

int main(int argc, char **argv)
{
	glyph_map fonts;
	glyph_map::iterator itr;

	if (argc < 2) {
		cerr << "usage: ./yaft2char FILE" << endl;
		return 1;
	}

	read_yaft(argv[1], fonts);

	itr = fonts.begin();
	while (itr != fonts.end()) {
			cout << itr->first << endl;
			dump_char(itr->second);
			itr++;
	}

	return 0;
}
