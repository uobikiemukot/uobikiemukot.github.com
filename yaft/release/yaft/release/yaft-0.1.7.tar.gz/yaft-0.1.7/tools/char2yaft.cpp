/*
	char2yaft: convert readable ascii format to yaft font
	usage: ./char2yaft FILE
*/
#include "util.cpp"

using namespace std;

void read_char(char *path, glyph_map &fonts)
{
	int i, state = 0, count = 0, wide;
	ifstream ifs;
	string str;
	vector<string> vec;

	glyph_t glyph;
	u16 code;
	u32 bitmap;

	ifs.open(path);

	while (getline(ifs, str)) {
		vec = split(str, ' ');
		switch (state) {
		case 0:
			reset_glyph(glyph);
			code = str2int(vec[0]);
			state = 1;
			break;
		case 1:
			glyph.width = str2int(vec[0]);
			glyph.height = str2int(vec[1]);
			wide = ceil((double) glyph.width / BITS_PER_BYTE) * BITS_PER_BYTE;
			state = 2;
			break;
		case 2:
			bitmap = 0;
			for (i = 0; i < wide; i++) {
				if (str[i] == '@')
					bitmap |= 0x01 << (wide - i - 1);
			}

			glyph.bitmap.push_back(bitmap);
			count++;
			if (count >= glyph.height) {
				if (fonts.find(code) != fonts.end())
					fonts.erase(code);
				fonts.insert(make_pair(code, glyph));
				count = state = 0;
			}
			break;
		default:
			break;
		}
	}

	ifs.close();
}

int main(int argc, char **argv)
{
	glyph_map fonts;
	glyph_map::iterator itr;

	if (argc < 2) {
		cerr << "usage: ./yaft2char FILE" << endl;
		return 1;
	}

	read_char(argv[1], fonts);

	itr = fonts.begin();
	while (itr != fonts.end()) {
			cout << itr->first << endl;
			dump_glyph(itr->second);
			itr++;
	}

	return 0;
}
