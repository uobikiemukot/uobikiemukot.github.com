/*
	checkwidth: check width of glyph of yaft font and print only valid glyph
	usage:
		./checkwidth WIDTH FONT
		./checkwidth WIDTH FONT -cjk
*/
#include "util.cpp"
#include "wcwidth.h"
#include <cstdlib>

int main(int argc, char **argv)
{
	int width, num;
	int (*func)(wchar_t ucs);
	glyph_map fonts;
	glyph_map::iterator itr;

	if (argc < 3) {
		cerr << "usage: ./yaft2char WIDTH FILE" << endl;
		cerr << "or ./yaft2char WIDTH FILE -cjk" << endl;
		return 1;
	}

	num = atoi(argv[1]);
	read_yaft(argv[2], fonts);

	if (argc > 3)
		func = mk_wcwidth;
	else
		func = mk_wcwidth_cjk;

	itr = fonts.begin();
	while (itr != fonts.end()) {
		width = num * func(itr->first);
		if (width > 0 && itr->second.width == width) {
			cout << itr->first << endl;
			dump_glyph(itr->second);
		}
		itr++;
	}

	return 0;
}
